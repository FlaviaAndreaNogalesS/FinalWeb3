export interface RefreshTokenResponse {
    access: string;
}
