export interface RegisterRequest {
    email: string;
    password: string;
    username: string; 
}
