export interface RegisterResponse {
    id: number;
    email: string;
}
